from django.apps import AppConfig


class SklepConfig(AppConfig):
    name = 'sklep'
